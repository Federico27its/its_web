let x = 10;

let y = x;

let z = "peppe";

console.log(x);
console.log(typeof(x));
document.getElementById("primo").innerText = `Valore ${x}, tipo ${typeof(x)}`;

console.log(y);
console.log(typeof(y));
document.getElementById("secondo").innerText = `Valore ${y}, tipo ${typeof(y)}`;


console.log(z);
console.log(typeof(z));
document.getElementById("terzo").innerText = `Valore ${z}, tipo ${typeof(z)}`;
