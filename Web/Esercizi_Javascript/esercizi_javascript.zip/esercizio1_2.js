let n = 100;

document.getElementById("primo").innerText = n;

n = 70;

document.getElementById("secondo").innerText = n;