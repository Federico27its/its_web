import React from 'react'

const Tabellina = () => {
  return (
    <div>Tabellina</div>
  )
}

export default Tabellina