export const anagrafica=[{
    id:"1",
    nome:"Rob",
    cognome:"Del"
  },{
    id:"2",
    nome:"mario",
    cognome:"Red"
  },{
    id:"3",
    nome:"laura",
    cognome:"bianchi"
  }];